# ✦ Supreme MD Bot ✦

A professional, high-performance WhatsApp bot built with `@whiskeysockets/baileys`. Optimized for speed, premium video quality, and aesthetic consistency.

## ✨ Key Features
- 🎥 **Premium Video Downloader**: Supports YouTube, TikTok, IG, FB with CRF 20 encoding and 720p HD scaling.
- ⚡ **Instant Response**: Non-blocking message handling for zero command lag.
- 📜 **Beautiful UI**: Centralized aesthetic theme with premium Unicode frames.
- 🔍 **Fast Search**: Built-in high-performance scrapers for YouTube and web results.
- 🔞 **NSFW Support**: Optional adult downloader module with secure admin toggles.
- 🏗️ **Self-Healing**: Automatic retry logic and robust anti-link protections.

## 🚀 Quick Setup

### 1. Prerequisites
- [Node.js](https://nodejs.org/) v18+
- [FFmpeg](https://ffmpeg.org/) (for video processing)
- git

### 2. Installation
```bash
git clone https://github.com/yourusername/Supreme-MD-Bot.git
cd Supreme-MD-Bot
npm install
```

### 3. Configuration
1. Rename `.env.example` to `.env`.
2. Edit `.env` with your your details:
   - `OWNER_NUMBER`: Your WhatsApp number (e.g., `947xxxxxxxx`)
   - `ADMIN_PASS`: Set a password for your web dashboard.

### 4. Start the Bot
```bash
npm start
```
Scan the QR code in your terminal to connect.

## 👑 Credits
Developed by **Supreme MD Team**. Based on the Baileys library.

## 📜 License
MIT
